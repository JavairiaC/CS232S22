Please note there are two parts in this assignment and both of them need to be submitted to Gradescope. Check the assignment
document for submission instructions

g++ --std=c++11 -g labyrinth/*.cpp -o ./twisty_labyrinth

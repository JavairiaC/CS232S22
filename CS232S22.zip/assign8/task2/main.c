int main() {
    int a=13,b=5, c;
    c=a+b;
}

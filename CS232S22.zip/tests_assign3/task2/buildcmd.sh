#!/bin/bash
cmd="gcc -Wall -std=c11 convert_2.c -o convert_2"
executable="convert_2"

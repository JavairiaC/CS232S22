#!/bin/bash
expected="mem_bug1.c mem_bug2.c mem_bug3.c"
